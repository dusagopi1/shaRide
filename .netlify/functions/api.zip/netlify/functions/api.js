const express = require('express');
const serverless = require('serverless-http');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const http = require('http');
const { Server } = require('socket.io');

// Load environment variables
dotenv.config();

// Create express app
const app = express();
app.use(express.json());

// Import routes from server directory
const authRoutes = require('../../server/routes/authRoutes');
const userRoutes = require('../../server/routes/userRoutes');
const rideRoutes = require('../../server/routes/rideRoutes');

// Apply routes with prefix
app.use('/.netlify/functions/api/auth', authRoutes);
app.use('/.netlify/functions/api/users', userRoutes);
app.use('/.netlify/functions/api/rides', rideRoutes);

// Configure MongoDB connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Add support for fallback polling in serverless environment
app.get('/.netlify/functions/api/rides/:rideId', async (req, res, next) => {
  try {
    // Get the timestamp from the request to check for updates since then
    const lastUpdateTime = req.query.timestamp ? new Date(parseInt(req.query.timestamp)) : null;
    
    // If this is a polling request (has timestamp), add update flags
    if (lastUpdateTime) {
      // Get the ride from database
      const Ride = require('../../server/models/Ride');
      const ride = await Ride.findById(req.params.rideId)
        .populate('driverId', 'username phone')
        .populate('matchedUserId', 'username phone');
      
      if (!ride) {
        return res.status(404).json({ error: 'Ride not found' });
      }
      
      // Check for updates since the timestamp
      const updates = [];
      
      // If the ride was updated after the timestamp
      if (ride.updatedAt > lastUpdateTime) {
        updates.push('ride-updated');
      }
      
      // If the ride was matched after the timestamp (rider joined)
      if (ride.matchedUserId && (!ride.matchedAt || ride.matchedAt > lastUpdateTime)) {
        updates.push('ride-joined');
      }
      
      // If ride was accepted after timestamp
      if (ride.status === 'confirmed' && (!ride.statusUpdatedAt || ride.statusUpdatedAt > lastUpdateTime)) {
        updates.push('ride-accepted');
      }
      
      // Return with updates flag and ride data
      return res.json({ 
        ride, 
        updates,
        timestamp: Date.now()
      });
    }
    
    // If not a polling request, proceed to regular handler
    next();
  } catch (error) {
    console.error('Error in polling endpoint:', error);
    next(error);
  }
});

// Setup Socket.IO for Netlify serverless function
const createSocketConnection = (server) => {
  const io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST', 'OPTIONS'],
      credentials: true,
      allowedHeaders: ['content-type', 'authorization']
    },
    path: '/.netlify/functions/api/socket.io',
    transports: ['polling'],               // Use only polling for serverless environment
    pingTimeout: 30000,                    // Increase timeout values
    pingInterval: 25000,                   // to prevent disconnections
    allowUpgrades: false,                  // Prevent transport upgrades
    cookie: false                          // Disable cookies for simpler cross-origin
  });

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    
    // Join a specific ride room
    socket.on('join-ride', (rideId) => {
      socket.join(rideId);
      console.log(`User ${socket.id} joined ride room: ${rideId}`);
    });

    // Handle location updates
    socket.on('location-update', (data) => {
      socket.to(data.rideId).emit('location-update', data);
    });

    // Handle ride creation
    socket.on('ride-created', (rideId, callback) => {
      console.log(`New ride created: ${rideId}`);
      socket.join(rideId);
      callback && callback({ success: true });
    });

    // Handle ride joining
    socket.on('ride-joined', (data, callback) => {
      console.log(`User ${data.username} joined ride: ${data.rideId}`);
      socket.join(data.rideId);
      socket.to(data.rideId).emit('ride-joined', data);
      callback && callback({ success: true });
    });

    // Handle ride acceptance
    socket.on('ride-accepted', (data, callback) => {
      console.log(`Ride accepted: ${data.rideId}`);
      io.to(data.rideId).emit('ride-accepted', data);
      callback && callback({ success: true });
    });

    // Handle ride declining
    socket.on('ride-declined', (data, callback) => {
      console.log(`Ride declined: ${data.rideId}`);
      io.to(data.rideId).emit('ride-declined', data);
      callback && callback({ success: true });
    });

    // Handle ride completion and rating events
    socket.on('ride-completed', (data) => {
      io.to(data.rideId).emit('ride-completed', data);
    });
    
    socket.on('ride-rated', (data) => {
      io.to(data.rideId).emit('ride-rated', data);
    });

    // Handle disconnection
    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  return io;
};

// Create an HTTP server for socket.io
const server = http.createServer(app);

// Initialize socket.io with the server
const io = createSocketConnection(server);

// Make io available on the app object
app.io = io;

// Create the serverless handler
const handler = serverless(app);

// Export a single handler for Netlify Functions
module.exports.handler = async (event, context) => {
  // Log socket.io requests for debugging
  if (event.httpMethod === 'GET' && event.path.includes('/socket.io')) {
    console.log('Socket.IO request detected:', event.path);
  }
  
  // For all requests, use the serverless handler
  return handler(event, context);
};
